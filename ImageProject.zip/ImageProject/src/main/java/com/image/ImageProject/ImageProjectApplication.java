package com.image.ImageProject;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class ImageProjectApplication {

	public static void main(String[] args) {
		SpringApplication.run(ImageProjectApplication.class, args);
	}

}

